package com.example.lance.weatherapp;

import android.os.Handler;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by Administrator on 2016/11/13 0013.
 */

public class HttpPM {
    private static final String part1 = "http://api.k780.com:88/?app=weather.pm25&weaid=";
    private static final String appKey = "21288";
    private static final String appSign = "26292f335d20835590c01d489b9a3358";
    //private static String pmRequests = "http://api.k780.com:88/?app=weather.pm25&weaid=城市编号&appkey=21288&sign=26292f335d20835590c01d489b9a3358&format=json";
    public static void pmRequest(final String city, final Handler handler, final PmCallBack pmCallBack)
    {
        final String request = part1+city+"&appkey="+appKey+"&sign="+appSign+"&format=json";
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                try {
                    URL url = new URL(request);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    InputStream inputStream = connection.getInputStream();
                    BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder response = new StringBuilder();
                    String tempLine;
                    while((tempLine = in.readLine())!=null)
                    {
                        response.append(tempLine);
                    }
                    PM pm = getPmData(response.toString());
                    if(pm!=null)
                        pmCallBack.onFinish(pm,handler);
                }catch (Exception e)
                {
                    pmCallBack.onError(e);
                }
                finally {
                    if(connection!=null)
                        connection.disconnect();
                }
            }
        }).start();
    }
    private static PM getPmData(String src)
    {
        PM pm = null;
        try{
            JSONObject object = new JSONObject(src);
            if(object.getString("success").equals("0"))
                return null;
            pm = new PM();
            JSONObject jsonObject = object.getJSONObject("result");
            pm.setCitynm(jsonObject.getString("citynm"));
            pm.setAqi(jsonObject.getString("aqi"));
            pm.setAqi_tips(jsonObject.getString("aqi_remark"));
            pm.setLevelname(jsonObject.getString("aqi_levnm"));
        }catch (JSONException e)
        {
            e.printStackTrace();
        }
        return pm;
    }
}
