package com.example.lance.weatherapp;

/**
 * Created by Administrator on 2016/11/14 0014.
 */

public class PM {
    private String aqi;
    private String citynm;
    private String levelname;
    private String aqi_tips;

    public String getAqi() {
        return aqi;
    }

    public void setAqi(String aqi) {
        this.aqi = aqi;
    }

    public String getCitynm() {
        return citynm;
    }

    public void setCitynm(String citynm) {
        this.citynm = citynm;
    }

    public String getLevelname() {
        return levelname;
    }

    public void setLevelname(String levelname) {
        this.levelname = levelname;
    }

    public String getAqi_tips() {
        return aqi_tips;
    }

    public void setAqi_tips(String aqi_tips) {
        this.aqi_tips = aqi_tips;
    }
}
