package com.example.lance.weatherapp;

/**
 * Created by Lance on 2016/12/7.
 */
public class City {
    public String citynm;
    public String cityweath;
    public String citytemp;
    public int cityw;

   public City(String citynm1,String cityweath1,String citytemp1,int cityw1){
       citynm = citynm1;
       cityweath = cityweath1;
       citytemp = citytemp1;
       cityw = cityw1;
   }
}
