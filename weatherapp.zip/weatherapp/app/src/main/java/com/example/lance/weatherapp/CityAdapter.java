package com.example.lance.weatherapp;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;
import static com.example.lance.weatherapp.Content.*;
/**
 * Created by Lance on 2016/12/7.
 */
public class CityAdapter extends BaseAdapter {

    private LayoutInflater inflater;
    private List<City> c;

    public CityAdapter(Context context){
        inflater = LayoutInflater.from(context);
        c = cityList;
    }
    @Override
    public int getCount() {
        return cityList.size();
    }

    @Override
    public Object getItem(int position) {
        return cityList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if(convertView == null){
            viewHolder = new ViewHolder();
            convertView = inflater.inflate(R.layout.citylist,null);
            viewHolder.citynm = (TextView) convertView.findViewById(R.id.citynm);
            viewHolder.cityweath = (TextView) convertView.findViewById(R.id.cityweath);
            viewHolder.citytemp = (TextView) convertView.findViewById(R.id.citytemp);
            viewHolder.city_back = (LinearLayout) convertView.findViewById(R.id.city_back);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.citynm.setText(cityList.get(position).citynm);
        viewHolder.cityweath.setText(cityList.get(position).cityweath);
        viewHolder.citytemp.setText(cityList.get(position).citytemp);
//        if(cityList.get(position).cityw==1){
//            viewHolder.city_back.setBackgroundResource(R.mipmap.s);
//        }else if(cityList.get(position).cityw== 2||cityList.get(position).cityw==3||cityList.get(position).cityw == 19){
//            viewHolder.city_back.setBackgroundResource(R.mipmap.y);
//        }else if((cityList.get(position).cityw>=7&&cityList.get(position).cityw<=13)||cityList.get(position).cityw==4){
//            viewHolder.city_back.setBackgroundResource(R.mipmap.r);
//        }else if(cityList.get(position).cityw==5||cityList.get(position).cityw==6){
//            viewHolder.city_back.setBackgroundResource(R.mipmap.l);
//        }else if(cityList.get(position).cityw>=30&&cityList.get(position).cityw<=33){
//            viewHolder.city_back.setBackgroundResource(R.mipmap.sha);
//        }else{
//            viewHolder.city_back.setBackgroundResource(R.mipmap.x);
//        }


        return convertView;
    }

    class ViewHolder{
        public TextView citynm;
        public  TextView cityweath;
        public TextView citytemp;
        public LinearLayout city_back;
    }
}
