package com.example.lance.weatherapp;

import android.os.Handler;

/**
 * Created by Administrator on 2016/11/14 0014.
 */

public interface PmCallBack {
    public void onFinish(PM pm, Handler handler);
    public void onError(Exception e);
}
