package com.example.lance.xiyou_score;

/**
 * Created by Lance on 2017/1/24.
 */
public class Content {

    static String course_content = null;
}
