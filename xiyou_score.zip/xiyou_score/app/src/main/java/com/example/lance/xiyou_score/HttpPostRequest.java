package com.example.lance.xiyou_score;

import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by Lance on 2017/1/21.
 */
public class HttpPostRequest extends StringRequest {
    Map<String,String> param;
    String cookie;

    public HttpPostRequest(int method, String url, Response.Listener<String> listener, Response.ErrorListener errorListener, Map<String, String> params, String cookies) {
        super(method, url, listener, errorListener);
        this.param = params;
        this.cookie = cookies;
    }

    public HttpPostRequest(String url, Response.Listener<String> listener, Response.ErrorListener errorListener, Map<String, String> params, String cookies) {
        super(url, listener, errorListener);
        this.param = params;
        this.cookie = cookies;
    }

    @Override
    public Map<String, String> getParams() throws AuthFailureError{
        return this.param;
    }

    @Override
    public byte[] getBody() throws AuthFailureError {
        Map params = this.getParams();
        return params != null&&params.size( )>0 ? this.encodeParameters(params,this.getParamsEncoding()):null;
    }

    private  byte[] encodeParameters(Map<String,String> params,String paramsEncoding){
        StringBuilder encodedParams = new StringBuilder();
        try {
            Iterator var5 = params.entrySet().iterator();

            while(var5.hasNext()) {
                java.util.Map.Entry uee = (java.util.Map.Entry)var5.next();
                encodedParams.append(URLEncoder.encode((String)uee.getKey(), paramsEncoding));
                encodedParams.append('=');
                encodedParams.append(URLEncoder.encode((String)uee.getValue(), paramsEncoding));
                encodedParams.append('&');
            }
            String answer = encodedParams.toString().substring(0,encodedParams.toString().length()-1);
            Log.e("answer",answer);
            return answer.getBytes(paramsEncoding);
        } catch (UnsupportedEncodingException var6) {
            throw new RuntimeException("Encoding not supported: " + paramsEncoding, var6);
        }
    }

    @Override
    public Map<String, String> getHeaders() throws AuthFailureError {
        Map<String,String> headers = new LinkedHashMap<>();
        headers.clear();
        headers.put("Accept-Encoding", "gzip, deflate");
        headers.put("Accept-Language","zh-CN,zh;q=0.8");
        headers.put("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
        headers.put("User-Agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36");
        headers.put("Cookie",cookie);
        headers.put("Referer","http://222.24.62.120/");
        headers.put("Pragma","no-cache");
        return headers;
    }
}
