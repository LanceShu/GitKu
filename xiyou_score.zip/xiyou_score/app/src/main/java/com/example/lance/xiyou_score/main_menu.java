package com.example.lance.xiyou_score;

import android.app.Activity;
import android.app.Application;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerTabStrip;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.GridView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by Lance on 2017/1/24.
 */
public class main_menu extends FragmentActivity implements ViewPager.OnPageChangeListener {

    private List<View> viewList;
    private ViewPager pager;
    private PagerTabStrip tabStrip;
    private List<String> titlelist;
    private List<Fragment> fragmentList;

    private GridView gv;
    private List<Map<String,Object>> dataList;
    private SimpleAdapter simpleAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu);

        gv = (GridView) findViewById(R.id.gv);
//        dataList = new ArrayList<>();
//        simpleAdapter = new SimpleAdapter(this,dataList,R.layout.course_item,new String[]{"course"},new int[]{R.id.course_item});
//        gv.setAdapter(simpleAdapter);

        viewList = new ArrayList<>();

        View view_course = View.inflate(this,R.layout.view1_course,null);
        View view_score = View.inflate(this,R.layout.view2_score,null);
        View view_project = View.inflate(this,R.layout.view3_project,null);

        viewList.add(view_course);
        viewList.add(view_score);
        viewList.add(view_project);

        fragmentList = new ArrayList<>();
        fragmentList.add(new Fragement_course());
        fragmentList.add(new Fragement_score());
        fragmentList.add(new Fragement_project());

        titlelist = new ArrayList<>();
        titlelist.add("课程表");
        titlelist.add("成绩单");
        titlelist.add("培养计划");

        tabStrip = (PagerTabStrip) findViewById(R.id.tab);
//        tabStrip.setBackgroundColor(null);
        tabStrip.setFocusableInTouchMode(true);
        tabStrip.setTextColor(Color.DKGRAY);
        tabStrip.setDrawFullUnderline(false);
        tabStrip.setTabIndicatorColor(Color.BLUE);

        pager = (ViewPager) findViewById(R.id.pager);

        FragementPagerAdapter fragementPagerAdapter = new FragementPagerAdapter(getSupportFragmentManager(),fragmentList,titlelist);
        pager.setAdapter(fragementPagerAdapter);
        pager.setOnPageChangeListener(this);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
