package com.example.lance.xiyou_score;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import static com.example.lance.xiyou_score.Content.*;

public class login_menu extends Activity implements View.OnClickListener{

    final static  String  VIEWSTATE = "dDwtNTE2MjI4MTQ7Oz5O9kSeYykjfN0r53Yqhqckbvd83A==";
    Map<String,String> responseHeaders;
    String cookies;
    RequestQueue mqueue;
    Document document;

    private EditText login_name;
    private EditText login_password;
    private EditText login_checkCode;
    private ImageView login_checkCode_image;
    private Button login_button;
    private Button login_cancel;
    private ImageView login_school_logo;

    private String loginName;
    private String loginPassword;
    private String loginCheckCode;

    private byte[] imagebytes;
    private int status = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.login);

        mqueue = Volley.newRequestQueue(this);
        login_name = (EditText) findViewById(R.id.login_name);
        login_password = (EditText) findViewById(R.id.login_password);
        login_checkCode = (EditText) findViewById(R.id.login_checkCode);
        login_checkCode_image = (ImageView) findViewById(R.id.login_checkCode_image);
        login_button = (Button) findViewById(R.id.login_button);
        login_cancel = (Button) findViewById(R.id.login_button_cancel);
        login_school_logo = (ImageView) findViewById(R.id.login_school_logo);

        login_button.setOnClickListener(this);
        login_cancel.setOnClickListener(this);

        schoolLogoImage();
        checkCodeImage();

        //getCookie();
    }

    private void checkCodeImage(){
        StringRequest getcheckcode = new StringRequest(Request.Method.GET, "http://222.24.62.120/CheckCode.aspx", new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(imagebytes, 0, imagebytes.length);
                login_checkCode_image.setImageBitmap(bitmap);
                Log.e("qwe", "success");
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {

            }
        }){
            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                imagebytes = response.data;
                Log.e("response_headers",response.headers+"");
                cookies = response.headers.get("Set-Cookie");
                String dataString = null;
                try{
                    dataString = new String(response.data,"UTF-8");
                    return Response.success(dataString, HttpHeaderParser.parseCacheHeaders(response));
                } catch (UnsupportedEncodingException e) {
                    return Response.error(new ParseError(e));
                }
            }
        };
        mqueue.add(getcheckcode);
    }


    private void schoolLogoImage() {
        RequestQueue mQueue1 = Volley.newRequestQueue(this);
        ImageLoader imageLoader1 = new ImageLoader(mQueue1, new ImageLoader.ImageCache() {
            @Override
            public Bitmap getBitmap(String s) {
                return null;
            }

            @Override
            public void putBitmap(String s, Bitmap bitmap) {

            }
        });
        ImageLoader.ImageListener listener1 = ImageLoader.getImageListener(login_school_logo, R.mipmap.ic_launcher, R.mipmap.ic_launcher);
        String school_logo_url = "http://222.24.62.120/logo/logo_school.png";
        imageLoader1.get(school_logo_url,listener1,0,100);
        Log.e("我是:", school_logo_url);
    }

    private void get_table(){
        StringRequest request = new StringRequest(Request.Method.POST, "http://222.24.62.120/xskbcx.aspx?xh=04152013&xm=%C1%F5%CA%F7%B1%F2&gnmkdm=N121603", new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                document = Jsoup.parse(s);
                Log.e("document:",document.select("#Table1").select("tbody")+"");
                course_content = document.select("#Table1")
                        .select("tbody").select("tr").text();
                Log.e("Content:",course_content);
                Log.e("asd", document.select("#Table1").size() + "");
                Intent intent = new Intent(login_menu.this,main_menu.class);
                startActivity(intent);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {

            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> header = new HashMap<>();
                header.put("Cookie",cookies);
                header.put("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
                header.put("Referer","http://222.24.62.120/xskbcx.aspx?xh=04152013&xm=%C1%F5%CA%F7%B1%F2&gnmkdm=N121603");
                header.put("Accept-Encoding","gzip, deflate");
                header.put("Accept-Language","zh-CN,zh;q=0.8");
                header.put("User-Agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36");
                Log.e("cookie", cookies + "123");
                return header;
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                Log.e("logincode",response.statusCode+"");
                return super.parseNetworkResponse(response);
            }

            @Override
            public byte[] getBody() throws AuthFailureError {
                return "__EVENTTARGET=xqd&__EVENTARGUMENT=&__VIEWSTATE=dDwzOTI4ODU2MjU7dDw7bDxpPDE%2BOz47bDx0PDtsPGk8MT47aTwyPjtpPDQ%2BO2k8Nz47aTw5PjtpPDExPjtpPDEzPjtpPDE1PjtpPDI0PjtpPDI2PjtpPDI4PjtpPDMwPjtpPDMyPjtpPDM0Pjs%2BO2w8dDxwPHA8bDxUZXh0Oz47bDxcZTs%2BPjs%2BOzs%2BO3Q8dDxwPHA8bDxEYXRhVGV4dEZpZWxkO0RhdGFWYWx1ZUZpZWxkOz47bDx4bjt4bjs%2BPjs%2BO3Q8aTwyPjtAPDIwMTYtMjAxNzsyMDE1LTIwMTY7PjtAPDIwMTYtMjAxNzsyMDE1LTIwMTY7Pj47bDxpPDA%2BOz4%2BOzs%2BO3Q8dDw7O2w8aTwxPjs%2BPjs7Pjt0PHA8cDxsPFRleHQ7PjtsPOWtpuWPt%2B%2B8mjA0MTUyMDEzOz4%2BOz47Oz47dDxwPHA8bDxUZXh0Oz47bDzlp5PlkI3vvJrliJjmoJHlvaw7Pj47Pjs7Pjt0PHA8cDxsPFRleHQ7PjtsPOWtpumZou%2B8muiuoeeul%2BacuuWtpumZojs%2BPjs%2BOzs%2BO3Q8cDxwPGw8VGV4dDs%2BO2w85LiT5Lia77ya572R57uc5bel56iLOz4%2BOz47Oz47dDxwPHA8bDxUZXh0Oz47bDzooYzmlL%2Fnj63vvJrnvZHnu5wxNTAxOz4%2BOz47Oz47dDw7bDxpPDE%2BOz47bDx0PEAwPDs7Ozs7Ozs7Ozs%2BOzs%2BOz4%2BO3Q8cDxsPFZpc2libGU7PjtsPG88Zj47Pj47bDxpPDE%2BOz47bDx0PEAwPDs7Ozs7Ozs7Ozs%2BOzs%2BOz4%2BO3Q8QDA8cDxwPGw8UGFnZUNvdW50O18hSXRlbUNvdW50O18hRGF0YVNvdXJjZUl0ZW1Db3VudDtEYXRhS2V5czs%2BO2w8aTwxPjtpPDA%2BO2k8MD47bDw%2BOz4%2BOz47Ozs7Ozs7Ozs7Pjs7Pjt0PEAwPHA8cDxsPFBhZ2VDb3VudDtfIUl0ZW1Db3VudDtfIURhdGFTb3VyY2VJdGVtQ291bnQ7RGF0YUtleXM7PjtsPGk8MT47aTwxPjtpPDE%2BO2w8Pjs%2BPjs%2BOzs7Ozs7Ozs7Oz47bDxpPDA%2BOz47bDx0PDtsPGk8MT47PjtsPHQ8O2w8aTwwPjtpPDE%2BO2k8Mj47aTwzPjtpPDQ%2BO2k8NT47aTw2Pjs%2BO2w8dDxwPHA8bDxUZXh0Oz47bDzltYzlhaXlvI%2Fns7vnu5%2Fmnb%2FnuqfnlLXot6%2Foo4XphY07Pj47Pjs7Pjt0PHA8cDxsPFRleHQ7PjtsPOWImOmSiui%2FnDs%2BPjs%2BOzs%2BO3Q8cDxwPGw8VGV4dDs%2BO2w8Mi4wOz4%2BOz47Oz47dDxwPHA8bDxUZXh0Oz47bDwwMS0xODs%2BPjs%2BOzs%2BO3Q8cDxwPGw8VGV4dDs%2BO2w8Jm5ic3BcOzs%2BPjs%2BOzs%2BO3Q8cDxwPGw8VGV4dDs%2BO2w8Jm5ic3BcOzs%2BPjs%2BOzs%2BO3Q8cDxwPGw8VGV4dDs%2BO2w8Jm5ic3BcOzs%2BPjs%2BOzs%2BOz4%2BOz4%2BOz4%2BO3Q8QDA8cDxwPGw8UGFnZUNvdW50O18hSXRlbUNvdW50O18hRGF0YVNvdXJjZUl0ZW1Db3VudDtEYXRhS2V5czs%2BO2w8aTwxPjtpPDA%2BO2k8MD47bDw%2BOz4%2BOz47Ozs7Ozs7Ozs7Pjs7Pjt0PEAwPHA8cDxsPFBhZ2VDb3VudDtfIUl0ZW1Db3VudDtfIURhdGFTb3VyY2VJdGVtQ291bnQ7RGF0YUtleXM7PjtsPGk8MT47aTwxPjtpPDE%2BO2w8Pjs%2BPjs%2BOzs7Ozs7Ozs7Oz47bDxpPDA%2BOz47bDx0PDtsPGk8MT47PjtsPHQ8O2w8aTwwPjtpPDE%2BO2k8Mj47aTwzPjtpPDQ%2BOz47bDx0PHA8cDxsPFRleHQ7PjtsPDIwMTYtMjAxNzs%2BPjs%2BOzs%2BO3Q8cDxwPGw8VGV4dDs%2BO2w8Mjs%2BPjs%2BOzs%2BO3Q8cDxwPGw8VGV4dDs%2BO2w85bWM5YWl5byP57O757uf5p2%2F57qn55S16Lev6KOF6YWNOz4%2BOz47Oz47dDxwPHA8bDxUZXh0Oz47bDzliJjpkorov5w7Pj47Pjs7Pjt0PHA8cDxsPFRleHQ7PjtsPDIuMDs%2BPjs%2BOzs%2BOz4%2BOz4%2BOz4%2BOz4%2BOz4%2BOz7ViEqNzWp8Fo1P7ve%2BsE4ff0tUTg%3D%3D&xnd=2016-2017&xqd=1".getBytes();
            }
        };
        mqueue.add(request);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.login_button:
                final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("please check message");
                builder.setPositiveButton("Yes", null);
                builder.setNegativeButton("Cancle", null);

                loginName = login_name.getText().toString();
                loginPassword = login_password.getText().toString();
                loginCheckCode = login_checkCode.getText().toString();

                Log.e("information:", loginName + "-" + loginPassword + "-" + loginCheckCode);

                StringRequest request = new StringRequest(Request.Method.POST, "http://222.24.62.120/default2.aspx", new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        Log.e("tag","3");
                    }
                }){
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String,String> header = new HashMap<>();
                        header.put("Cookie",cookies);
                        header.put("Referer","http://222.24.62.120/");
                        header.put("Accept-Encoding","gzip, deflate");
                        header.put("Origin","http://222.24.62.120");
                        header.put("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
                        header.put("Accept-Language","zh-CN,zh;q=0.8");
                        header.put("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36");
                        Log.e("cookie",cookies+"1111111");
                        return header;
                    }

                    @Override
                    protected Response<String> parseNetworkResponse(NetworkResponse response) {
                        Map<String,String> headers = response.headers;
                        Log.e("statusCode",response.statusCode+"");
                        String datastring = null;
                        try{
                            datastring = new String(response.data,"UTF-8");
                            return Response.success(datastring,HttpHeaderParser.parseCacheHeaders(response));
                        } catch (UnsupportedEncodingException e) {
                            return Response.error(new ParseError(e));
                        }
                    }

                    @Override
                    public byte[] getBody() throws AuthFailureError {
                        return ("__VIEWSTATE=dDwtNTE2MjI4MTQ7Oz5O9kSeYykjfN0r53Yqhqckbvd83A%3D%3D&txtUserName="+loginName+"&Textbox1=&TextBox2="+loginPassword+"&txtSecretCode="+loginCheckCode+"&RadioButtonList1=%D1%A7%C9%FA&Button1=&lbLanguage=&hidPdrs=&hidsc=").getBytes();
                    }
                };
                mqueue.add(request);
                get_table();
                break;

            case R.id.login_checkCode_image:

                break;
            case R.id.login_button_cancel:
                finish();
                break;
            default:
                break;
        }
    }

}

