package com.example.lance.xiyou_score;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity implements View.OnClickListener{

    final static  String  VIEWSTATE = "dDwtNTE2MjI4MTQ7Oz5O9kSeYykjfN0r53Yqhqckbvd83A==";
    Map<String,String> responseHeaders;
    String cookies;
    RequestQueue mqueue;

    private EditText login_name;
    private EditText login_password;
    private EditText login_checkCode;
    private ImageView login_checkCode_image;
    private Button login_button;
    private Button login_cancel;
    private ImageView login_school_logo;

    private String loginName;
    private String loginPassword;
    private String loginCheckCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.login);

        mqueue = Volley.newRequestQueue(this);
        login_name = (EditText) findViewById(R.id.login_name);
        login_password = (EditText) findViewById(R.id.login_password);
        login_checkCode = (EditText) findViewById(R.id.login_checkCode);
        login_checkCode_image = (ImageView) findViewById(R.id.login_checkCode_image);
        login_button = (Button) findViewById(R.id.login_button);
        login_cancel = (Button) findViewById(R.id.login_button_cancel);
        login_school_logo = (ImageView) findViewById(R.id.login_school_logo);

        login_button.setOnClickListener(this);
        login_cancel.setOnClickListener(this);

        schoolLogoImage();
        checkCodeImage();

        //getCookie();
    }

    public String getCookies() {
        // Log.e("Headers",responseHeaders.toString());
        if (responseHeaders == null)
            return null;
        else {
            Log.e("COokie", responseHeaders.get("Set-Cookie").substring(0, responseHeaders.get("Set-Cookie").length()-6));
            return responseHeaders.get("Set-Cookie").substring(0, responseHeaders.get("Set-Cookie").length() - 6);
        }
    }

    public void setResponseHeaders(Map<String, String> responseHeaders) {
        this.responseHeaders = responseHeaders;
    }

    public Map<String, String> getResponseHeaders() {
        return responseHeaders;
    }

    private void checkCodeImage(){
        ImageRequest imageRequest = new ImageRequest("http://222.24.62.120/CheckCode.aspx", new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap bitmap) {
                login_checkCode_image.setImageBitmap(bitmap);
            }
        }, 0, 50, Bitmap.Config.RGB_565, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                login_checkCode_image.setImageResource(R.mipmap.ic_launcher);
            }
        }){
            @Override
            protected Response<Bitmap> parseNetworkResponse(NetworkResponse response) {
                setResponseHeaders(response.headers);
                return super.parseNetworkResponse(response);
            }
        };
        mqueue.add(imageRequest);
    }

//    private void checkCodeImage() {
//        RequestQueue mQueue2 = Volley.newRequestQueue(this);
//        ImageLoader imageLoader = new ImageLoader(mQueue2, new ImageLoader.ImageCache() {
//            @Override
//            public Bitmap getBitmap(String s) {
//                return null;
//            }
//
//            @Override
//            public void putBitmap(String s, Bitmap bitmap) {
//
//            }
//        });
//        ImageLoader.ImageListener listener = ImageLoader.getImageListener(login_checkCode_image, R.mipmap.ic_launcher, R.mipmap.ic_launcher);
//        String checkCodeUrl = "http://222.24.62.120/CheckCode.aspx";
//        imageLoader.get(checkCodeUrl, listener, 0, 500);
//    }

    private void schoolLogoImage() {
        RequestQueue mQueue1 = Volley.newRequestQueue(this);
        ImageLoader imageLoader1 = new ImageLoader(mQueue1, new ImageLoader.ImageCache() {
            @Override
            public Bitmap getBitmap(String s) {
                return null;
            }

            @Override
            public void putBitmap(String s, Bitmap bitmap) {

            }
        });
        ImageLoader.ImageListener listener1 = ImageLoader.getImageListener(login_school_logo, R.mipmap.ic_launcher, R.mipmap.ic_launcher);
        String school_logo_url = "http://222.24.62.120/logo/logo_school.png";
        imageLoader1.get(school_logo_url,listener1,0,100);
        Log.e("我是:", school_logo_url);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.login_button:
                final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("please check message");
                builder.setPositiveButton("Yes", null);
                builder.setNegativeButton("Cancle",null);

                loginName = login_name.getText().toString();
                loginPassword = login_password.getText().toString();
                loginCheckCode = login_checkCode.getText().toString();

                Log.e("information:", loginName + "-" + loginPassword + "-" + loginCheckCode);

                Map<String,String> params = createParams(loginName,loginPassword,loginCheckCode);
                HttpPostRequest login = new HttpPostRequest(Request.Method.POST, "http://222.24.62.120/default2.aspx", new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        builder.setMessage("GetMessage");
                        Log.e("response  ", s);
                        builder.create().show();
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        builder.setMessage("Error.");
                        if (volleyError!=null)
                            Log.d("ERROR  ",volleyError.toString());
                        else
                            Log.d("ERROR","\tNULL");
                        builder.create().show();
                    }
                },params,getCookies());
                login.setShouldCache(false);
                mqueue.add(login);
                break;

            case R.id.login_checkCode_image:

                break;
            case R.id.login_button_cancel:
                finish();
                break;
            default:
                break;
        }
    }

    private Map<String, String> createParams(String loginName, String loginPassword, String loginCheckCode) {
        Map<String,String> map = new LinkedHashMap<>();
        map.clear();
        map.put("__VIEWSTATE", VIEWSTATE);
        map.put("txtUserName",loginName);
        map.put("Textbox1","");
        map.put("Textbox2",loginPassword);
        map.put("txtSecretCode",loginCheckCode);
        map.put("RadioButtonList1","学生");
        map.put("Button1","");
        map.put("lbLanguage","");
        map.put("hidPdrs","");
        map.put("hidsc","");
        return map;
    }


}

